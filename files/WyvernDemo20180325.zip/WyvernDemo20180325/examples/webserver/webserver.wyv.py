def mergeDicts(l, r):
  l.update(r)
  return r

def trampoline(f, *args, **kwargs):
  res = f(*args, **kwargs)
  while callable(res):
    res = res()
  return res

class PythonPrelude:
  def toString(self, x):
    return str(x)
ffi_python = PythonPrelude()

class Class4:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_setHeaders(wyvthis, wyvhrh):
    def tcoFn8():
      try:
        return wyvthis.env['wyvvar_17'].tco_setHeaders(wyvhrh)
      except AttributeError:
        return wyvthis.env['wyvvar_17'].setHeaders(wyvhrh)
      
    
    
    return tcoFn8
  def setHeaders(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_setHeaders, wyvhrh)
  
  def tco_doGET(wyvthis, wyvhrh):
    def tcoFn9():
      try:
        return wyvthis.env['wyvvar_17'].tco_doGET(wyvhrh)
      except AttributeError:
        return wyvthis.env['wyvvar_17'].doGET(wyvhrh)
      
    
    
    return tcoFn9
  def doGET(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_doGET, wyvhrh)
  
  def tco_doHEAD(wyvthis, wyvhrh):
    def tcoFn10():
      try:
        return wyvthis.env['wyvvar_17'].tco_doHEAD(wyvhrh)
      except AttributeError:
        return wyvthis.env['wyvvar_17'].doHEAD(wyvhrh)
      
    
    
    return tcoFn10
  def doHEAD(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_doHEAD, wyvhrh)
  
  def tco_doPOST(wyvthis, wyvhrh):
    def tcoFn11():
      try:
        return wyvthis.env['wyvvar_17'].tco_doPOST(wyvhrh)
      except AttributeError:
        return wyvthis.env['wyvvar_17'].doPOST(wyvhrh)
      
    
    
    return tcoFn11
  def doPOST(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_doPOST, wyvhrh)
  
class Class1:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  
  
class Class2:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  
  
class Class3:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_setHeaders(wyvthis, wyvhrh):
    
    def letFn14(wyvvar_20):
      def letFn13(wyvvar_21):
        
        def tcoFn12():
          try:
            return wyvhrh.tco_end_headers()
          except AttributeError:
            return wyvhrh.end_headers()
          
        
        
        return tcoFn12
      
      return letFn13(wyvhrh.send_header("Content-type", "text/html"))
    
    return letFn14(wyvhrh.send_response(200))
  def setHeaders(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_setHeaders, wyvhrh)
  
  def tco_doGET(wyvthis, wyvhrh):
    
    def letFn16(wyvvar_23):
      
      def tcoFn15():
        try:
          return wyvhrh.wfile.tco_write("<html><body><h1>Hello there!</h1></body></html>")
        except AttributeError:
          return wyvhrh.wfile.write("<html><body><h1>Hello there!</h1></body></html>")
        
      
      
      return tcoFn15
    
    return letFn16(wyvthis.env['wyvvar_17'].setHeaders(wyvhrh))
  def doGET(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_doGET, wyvhrh)
  
  def tco_doHEAD(wyvthis, wyvhrh):
    def tcoFn17():
      try:
        return wyvthis.env['wyvvar_17'].tco_setHeaders(wyvhrh)
      except AttributeError:
        return wyvthis.env['wyvvar_17'].setHeaders(wyvhrh)
      
    
    
    return tcoFn17
  def doHEAD(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_doHEAD, wyvhrh)
  
  def tco_doPOST(wyvthis, wyvhrh):
    
    def letFn19(wyvvar_25):
      
      def tcoFn18():
        try:
          return wyvhrh.wfile.tco_write("<html><body><h1>POST request received!</h1></body></html>")
        except AttributeError:
          return wyvhrh.wfile.write("<html><body><h1>POST request received!</h1></body></html>")
        
      
      
      return tcoFn18
    
    return letFn19(wyvthis.env['wyvvar_17'].setHeaders(wyvhrh))
  def doPOST(wyvthis, wyvhrh):
    return trampoline(wyvthis.tco_doPOST, wyvhrh)
  

def letFn7(wyvMOD__HTTPRequestHandler):
  def letFn3():
    def letFn6(wyvMOD__HTTPRequestHandler):
      def letFn5(wyvHTTPRequestHandler):
        def letFn4(wyvvar_17):
          return Class4(env=({'wyvvar_17': wyvvar_17}))
        
        return letFn4(Class3(env=({}), thisName = "wyvvar_17"))
      
      return letFn5(wyvMOD__HTTPRequestHandler)
    
    return letFn6(Class2(env=({}), thisName = "wyvMOD__HTTPRequestHandler"))
  def letFn2(wyvMOD__wyvernHandler):
    import webserver
    def letFn1(wyvwebserver):
      def letFn0(wyvwyvernHandler):
        return wyvwebserver.run(wyvMOD__wyvernHandler)
      
      return letFn0(wyvMOD__wyvernHandler)
    
    return letFn1(webserver)
  
  return letFn2(letFn3())

print(letFn7(Class1(env=({}), thisName = "wyvMOD__HTTPRequestHandler")))

