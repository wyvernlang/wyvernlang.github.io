def mergeDicts(l, r):
  l.update(r)
  return r

def trampoline(f, *args, **kwargs):
  res = f(*args, **kwargs)
  while callable(res):
    res = res()
  return res

class PythonPrelude:
  def toString(self, x):
    return str(x)
ffi_python = PythonPrelude()

class Class12:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  
  
class Class11:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  
class Class14:
  def __init__(this, sys, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
    this.sys = sys
  
  
  
  
  def tco_pykwd_print(wyvthis, wyvtext):
    def tcoFn8():
      try:
        return wyvthis.env['wyvvar_20'].tco_pykwd_print(wyvtext)
      except AttributeError:
        return wyvthis.env['wyvvar_20'].pykwd_print(wyvtext)
      
    
    
    return tcoFn8
  def pykwd_print(wyvthis, wyvtext):
    return trampoline(wyvthis.tco_pykwd_print, wyvtext)
  
  def tco_printInt(wyvthis, wyvn):
    def tcoFn9():
      try:
        return wyvthis.env['wyvvar_20'].tco_printInt(wyvn)
      except AttributeError:
        return wyvthis.env['wyvvar_20'].printInt(wyvn)
      
    
    
    return tcoFn9
  def printInt(wyvthis, wyvn):
    return trampoline(wyvthis.tco_printInt, wyvn)
  
  def tco_println(wyvthis):
    def tcoFn10():
      try:
        return wyvthis.env['wyvvar_20'].tco_println()
      except AttributeError:
        return wyvthis.env['wyvvar_20'].println()
      
    
    
    return tcoFn10
  def println(wyvthis):
    return trampoline(wyvthis.tco_println)
  
class Class13:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_pykwd_print(wyvthis, wyvtext):
    def tcoFn11():
      try:
        return wyvthis.env['wyvsys'].stdout.tco_write(wyvtext)
      except AttributeError:
        return wyvthis.env['wyvsys'].stdout.write(wyvtext)
      
    
    
    return tcoFn11
  def pykwd_print(wyvthis, wyvtext):
    return trampoline(wyvthis.tco_pykwd_print, wyvtext)
  
  def tco_printInt(wyvthis, wyvn):
    def tcoFn12():
      try:
        return wyvthis.env['wyvsys'].stdout.tco_write(wyvthis.env['wyvMOD__wyvern___String'].apply(wyvthis.env['wyvpython']).ofInt(wyvn))
      except AttributeError:
        return wyvthis.env['wyvsys'].stdout.write(wyvthis.env['wyvMOD__wyvern___String'].apply(wyvthis.env['wyvpython']).ofInt(wyvn))
      
    
    
    return tcoFn12
  def printInt(wyvthis, wyvn):
    return trampoline(wyvthis.tco_printInt, wyvn)
  
  def tco_println(wyvthis):
    def tcoFn13():
      try:
        return wyvthis.env['wyvsys'].stdout.tco_write("\n")
      except AttributeError:
        return wyvthis.env['wyvsys'].stdout.write("\n")
      
    
    
    return tcoFn13
  def println(wyvthis):
    return trampoline(wyvthis.tco_println)
  
class Class16:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_apply(wyvthis, wyvpython):
    def tcoFn14():
      try:
        return Class15(env=mergeDicts(wyvthis.env, {'wyvMOD__wyvern___String': wyvthis.env['wyvMOD__wyvern___String']})).tco_apply(wyvpython)
      except AttributeError:
        return Class15(env=mergeDicts(wyvthis.env, {'wyvMOD__wyvern___String': wyvthis.env['wyvMOD__wyvern___String']})).apply(wyvpython)
      
    
    
    return tcoFn14
  def apply(wyvthis, wyvpython):
    return trampoline(wyvthis.tco_apply, wyvpython)
  
class Class15:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_apply(wyvthis, wyvpython):
    
    def letFn20(wyvString):
      import sys
      def letFn19(wyvsys):
        def letFn18(wyvvar_18):
          def letFn17(wyvvar_19):
            def letFn16(wyvsys):
              def letFn15(wyvvar_20):
                return Class14(wyvsys, env=mergeDicts(wyvthis.env, {'wyvsys': wyvsys, 'wyvvar_20': wyvvar_20}))
              
              return letFn15(Class13(env=mergeDicts(wyvthis.env, {'wyvMOD__wyvern___String': wyvthis.env['wyvMOD__wyvern___String'], 'wyvsys': wyvsys, 'wyvpython': wyvpython}), thisName = "wyvvar_20"))
            
            return letFn16(wyvsys)
          
          return letFn17(Class12(env=mergeDicts(wyvthis.env, {}), thisName = "wyvvar_19"))
        
        return letFn18(Class11(env=mergeDicts(wyvthis.env, {}), thisName = "wyvvar_18"))
      
      return letFn19(sys)
    
    return letFn20(wyvthis.env['wyvMOD__wyvern___String'])
  def apply(wyvthis, wyvpython):
    return trampoline(wyvthis.tco_apply, wyvpython)
  
class Class17:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_run(wyvthis):
    
    def letFn24(wyvserver_address):
      def letFn23(wyvhttpd):
        def letFn22(wyvvar_29):
          
          def tcoFn21():
            try:
              return wyvhttpd.tco_serve_forever()
            except AttributeError:
              return wyvhttpd.serve_forever()
            
          
          
          return tcoFn21
        
        return letFn22(wyvthis.env['wyvstdout'].pykwd_print("Starting httpd..."))
      
      return letFn23(wyvthis.env['wyvbaseHTTPServer'].HTTPServer(wyvserver_address, wyvthis.env['wyvbaseHTTPServer'].BaseHTTPRequestHandler))
    
    return letFn24(wyvthis.env['wyvhelper'].make2Tuple("", 8888))
  def run(wyvthis):
    return trampoline(wyvthis.tco_run)
  
class Class4:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_apply(wyvthis, wyvpython):
    def tcoFn25():
      try:
        return Class3(env=mergeDicts(wyvthis.env, {})).tco_apply(wyvpython)
      except AttributeError:
        return Class3(env=mergeDicts(wyvthis.env, {})).apply(wyvpython)
      
    
    
    return tcoFn25
  def apply(wyvthis, wyvpython):
    return trampoline(wyvthis.tco_apply, wyvpython)
  
class Class5:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  
class Class6:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  
  
class Class7:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_pykwd_print(wyvthis, wyvtext):
    def tcoFn26():
      try:
        return wyvthis.env['wyvsys'].stdout.tco_write(wyvtext)
      except AttributeError:
        return wyvthis.env['wyvsys'].stdout.write(wyvtext)
      
    
    
    return tcoFn26
  def pykwd_print(wyvthis, wyvtext):
    return trampoline(wyvthis.tco_pykwd_print, wyvtext)
  
  def tco_printInt(wyvthis, wyvn):
    def tcoFn27():
      try:
        return wyvthis.env['wyvsys'].stdout.tco_write(wyvthis.env['wyvMOD__wyvern___String'].apply(wyvthis.env['wyvpython']).ofInt(wyvn))
      except AttributeError:
        return wyvthis.env['wyvsys'].stdout.write(wyvthis.env['wyvMOD__wyvern___String'].apply(wyvthis.env['wyvpython']).ofInt(wyvn))
      
    
    
    return tcoFn27
  def printInt(wyvthis, wyvn):
    return trampoline(wyvthis.tco_printInt, wyvn)
  
  def tco_println(wyvthis):
    def tcoFn28():
      try:
        return wyvthis.env['wyvsys'].stdout.tco_write("\n")
      except AttributeError:
        return wyvthis.env['wyvsys'].stdout.write("\n")
      
    
    
    return tcoFn28
  def println(wyvthis):
    return trampoline(wyvthis.tco_println)
  
class Class1:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_equals(wyvthis, wyvstr1, wyvstr2):
    def tcoFn29():
      try:
        return wyvthis.env['wyvpython'].tco_isEqual(wyvstr1, wyvstr2)
      except AttributeError:
        return wyvthis.env['wyvpython'].isEqual(wyvstr1, wyvstr2)
      
    
    
    return tcoFn29
  def equals(wyvthis, wyvstr1, wyvstr2):
    return trampoline(wyvthis.tco_equals, wyvstr1, wyvstr2)
  
  def tco_ofInt(wyvthis, wyvx):
    def tcoFn30():
      try:
        return wyvthis.env['wyvpython'].tco_toString(wyvx)
      except AttributeError:
        return wyvthis.env['wyvpython'].toString(wyvx)
      
    
    
    return tcoFn30
  def ofInt(wyvthis, wyvx):
    return trampoline(wyvthis.tco_ofInt, wyvx)
  
class Class10:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_apply(wyvthis, wyvpython):
    def tcoFn31():
      try:
        return Class9(env=mergeDicts(wyvthis.env, {'wyvMOD__wyvern___String': wyvthis.env['wyvMOD__wyvern___String']})).tco_apply(wyvpython)
      except AttributeError:
        return Class9(env=mergeDicts(wyvthis.env, {'wyvMOD__wyvern___String': wyvthis.env['wyvMOD__wyvern___String']})).apply(wyvpython)
      
    
    
    return tcoFn31
  def apply(wyvthis, wyvpython):
    return trampoline(wyvthis.tco_apply, wyvpython)
  
class Class2:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_equals(wyvthis, wyvstr1, wyvstr2):
    def tcoFn32():
      try:
        return wyvthis.env['wyvvar_16'].tco_equals(wyvstr1, wyvstr2)
      except AttributeError:
        return wyvthis.env['wyvvar_16'].equals(wyvstr1, wyvstr2)
      
    
    
    return tcoFn32
  def equals(wyvthis, wyvstr1, wyvstr2):
    return trampoline(wyvthis.tco_equals, wyvstr1, wyvstr2)
  
  def tco_ofInt(wyvthis, wyvx):
    def tcoFn33():
      try:
        return wyvthis.env['wyvvar_16'].tco_ofInt(wyvx)
      except AttributeError:
        return wyvthis.env['wyvvar_16'].ofInt(wyvx)
      
    
    
    return tcoFn33
  def ofInt(wyvthis, wyvx):
    return trampoline(wyvthis.tco_ofInt, wyvx)
  
class Class3:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_apply(wyvthis, wyvpython):
    
    def letFn34(wyvvar_16):
      return Class2(env=mergeDicts(wyvthis.env, {'wyvvar_16': wyvvar_16}))
    
    return letFn34(Class1(env=mergeDicts(wyvthis.env, {'wyvpython': wyvpython}), thisName = "wyvvar_16"))
  def apply(wyvthis, wyvpython):
    return trampoline(wyvthis.tco_apply, wyvpython)
  
class Class8:
  def __init__(this, sys, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
    this.sys = sys
  
  
  
  
  def tco_pykwd_print(wyvthis, wyvtext):
    def tcoFn35():
      try:
        return wyvthis.env['wyvvar_20'].tco_pykwd_print(wyvtext)
      except AttributeError:
        return wyvthis.env['wyvvar_20'].pykwd_print(wyvtext)
      
    
    
    return tcoFn35
  def pykwd_print(wyvthis, wyvtext):
    return trampoline(wyvthis.tco_pykwd_print, wyvtext)
  
  def tco_printInt(wyvthis, wyvn):
    def tcoFn36():
      try:
        return wyvthis.env['wyvvar_20'].tco_printInt(wyvn)
      except AttributeError:
        return wyvthis.env['wyvvar_20'].printInt(wyvn)
      
    
    
    return tcoFn36
  def printInt(wyvthis, wyvn):
    return trampoline(wyvthis.tco_printInt, wyvn)
  
  def tco_println(wyvthis):
    def tcoFn37():
      try:
        return wyvthis.env['wyvvar_20'].tco_println()
      except AttributeError:
        return wyvthis.env['wyvvar_20'].println()
      
    
    
    return tcoFn37
  def println(wyvthis):
    return trampoline(wyvthis.tco_println)
  
class Class9:
  def __init__(this, env={}, delegate=None, thisName=None):
    this.env = env
    this.delegate = delegate
    if thisName is not None:
      this.env[thisName] = this
  def tco_apply(wyvthis, wyvpython):
    
    def letFn43(wyvString):
      import sys
      def letFn42(wyvsys):
        def letFn41(wyvvar_18):
          def letFn40(wyvvar_19):
            def letFn39(wyvsys):
              def letFn38(wyvvar_20):
                return Class8(wyvsys, env=mergeDicts(wyvthis.env, {'wyvsys': wyvsys, 'wyvvar_20': wyvvar_20}))
              
              return letFn38(Class7(env=mergeDicts(wyvthis.env, {'wyvMOD__wyvern___String': wyvthis.env['wyvMOD__wyvern___String'], 'wyvsys': wyvsys, 'wyvpython': wyvpython}), thisName = "wyvvar_20"))
            
            return letFn39(wyvsys)
          
          return letFn40(Class6(env=mergeDicts(wyvthis.env, {}), thisName = "wyvvar_19"))
        
        return letFn41(Class5(env=mergeDicts(wyvthis.env, {}), thisName = "wyvvar_18"))
      
      return letFn42(sys)
    
    return letFn43(wyvthis.env['wyvMOD__wyvern___String'])
  def apply(wyvthis, wyvpython):
    return trampoline(wyvthis.tco_apply, wyvpython)
  

def letFn7(wyvMOD__wyvern___String):
  def letFn6(wyvMOD__stdout):
    def letFn5(wyvstdout):
      import BaseHTTPServer
      def letFn4(wyvBaseHTTPServer):
        import helper
        def letFn3(wyvhelper):
          def letFn2(wyvbaseHTTPServer):
            def letFn1(wyvhelper):
              def letFn0(wyvvar_22):
                return wyvvar_22.run()
              
              return letFn0(Class17(env=({'wyvstdout': wyvstdout, 'wyvhelper': wyvhelper, 'wyvbaseHTTPServer': wyvbaseHTTPServer}), thisName = "wyvvar_22"))
            
            return letFn1(wyvhelper)
          
          return letFn2(wyvBaseHTTPServer)
        
        return letFn3(helper)
      
      return letFn4(BaseHTTPServer)
    
    return letFn5(Class16(env=({'wyvMOD__wyvern___String': wyvMOD__wyvern___String})).apply(ffi_python))
  
  return letFn6(Class10(env=({'wyvMOD__wyvern___String': wyvMOD__wyvern___String}), thisName = "wyvMOD__stdout"))

print(letFn7(Class4(env=({}), thisName = "wyvMOD__wyvern___String")))

