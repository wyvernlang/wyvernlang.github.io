Requirements

You must install and compile wyvern, install python, and install the pygame module (use "pip install pygame")


To run the pong example, go to this directory (examples/pong) and use the commands:

wypy pong.wyv
python pong.wyv.py