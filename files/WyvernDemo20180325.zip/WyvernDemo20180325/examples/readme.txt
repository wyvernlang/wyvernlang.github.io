Wyvern Examples
===============

pong/           a pong game implemented in Wyvern on the Python platform
rosetta/        simple example programs in Wyvern from http://rosettacode.org
capabilities/   an example illustrating capability-based module systems
tsls/           an example illustrating type-specific languages

To run the examples on the Java platform, from the current directory "examples" execute the command:

wyvern rosetta/hello.wyv

(or similar for other examples)


To run the pong example, which requires python, see the readme.txt file in the pong subdirectory.
